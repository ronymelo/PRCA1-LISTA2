﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista2Ex4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double nbase;
            double altura;
            double area;

            Console.WriteLine("\n---------Exercício 4 da Lista 2---------\n");

            Console.Write("Informe a Base do Retângulo (m): ");
            nbase = double.Parse(Console.ReadLine());

            Console.Write("Informe a altura do Retângulo (m): ");
            altura = double.Parse(Console.ReadLine());

            Console.WriteLine("");

            area = nbase * altura;

            Console.WriteLine("A Área do Retângulo Vale: {0} m²", area);
            if (area > 100)
            {
                Console.WriteLine("Terreno Grande");
            }
        }
    }
}
