﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista2Ex10
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double p1;
            double p2;
            double media;

            Console.WriteLine("\n---------Exercício 10 da Lista 2---------\n");

            Console.Write("Informe a Nota da P1: ");
            p1 = double.Parse(Console.ReadLine());

            Console.Write("Informe a Nota da P2: ");
            p2 = double.Parse(Console.ReadLine());

            Console.WriteLine("");

            media = (p1 + 2 * p2) / 3;

            Console.WriteLine("Média: {0:f1}",media);

            if (media >= 5)
            {
                Console.WriteLine("Aprovado");
            }
            else
            {
                Console.WriteLine("Reprovado");
            }
        }
    }
}
